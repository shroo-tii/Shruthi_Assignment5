
import java.util.Scanner;
public class Bank {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.println("1\t AAA Bank");
        System.out.println("2\t BBB Bank");
        System.out.println("3\t CCC Bank");
        System.out.println("4\t DDD Bank");

        System.out.println("Please enter your choice in number:");
        int choice = in.nextInt();
        switch (choice) {

            case 1:
                System.out.println("You have chosen AAA Bank \n");
                System.out.println("Now choose the loan type \n");
                System.out.println("1. Educational Loan \n 2.House Loan");
                int aaa = in.nextInt();
                switch (aaa) {
                    case 1:
                        double p, t, calc;
                        System.out.println("Enter the amount:");
                        Scanner scan = new Scanner(System.in);
                        p = scan.nextFloat();
                        System.out.println("Enter the Time Period:");
                        t = scan.nextFloat();
                        scan.close();
                        float interest = 0.014f;
                        calc = (p * interest * Math.pow(1 + interest, t)) / (Math.pow(1 + interest, t) - 1);
                        System.out.println("The Interest is:" + calc);
                        System.out.println("In Time Period:" + t);
                        break;

                    case 2:
                        double Prin, ti, cal;
                        System.out.println("Enter the amount:");
                        Scanner sca = new Scanner(System.in);
                        Prin = sca.nextFloat();
                        System.out.println("Enter the Time Period:");
                        ti = sca.nextFloat();
                        sca.close();
                        float inte = 0.005f;
                        cal = (Prin * inte * Math.pow(1 + inte, ti)) / (Math.pow(1 + inte, ti) - 1);
                        System.out.println("The Interest is:" + cal);
                        System.out.println("In Time Period:" + ti);
                        break;
                }
                break;


            case 2:
                System.out.println("You have chosen BBB Bank");
                System.out.println("Now choose the loan type \n");
                System.out.println("1. Educational Loan \n 2.House Loan");
                int bbb = in.nextInt();
                switch (bbb) {
                    case 1:
                        double p, t, calc;
                        System.out.println("Enter the amount:");
                        Scanner scan = new Scanner(System.in);
                        p = scan.nextFloat();
                        System.out.println("Enter the Time Period:");
                        t = scan.nextFloat();
                        scan.close();
                        float interest = 0.0058f;
                        calc = (p * interest * Math.pow(1 + interest, t)) / (Math.pow(1 + interest, t) - 1);
                        System.out.println("The Interest is:" + calc);
                        System.out.println("In Time Period:" + t);
                        break;

                    case 2:
                        double prin, ti, cal;
                        System.out.println("Enter the amount:");
                        Scanner sc = new Scanner(System.in);
                        prin = sc.nextFloat();
                        System.out.println("Enter the Time Period:");
                        ti = sc.nextFloat();
                        sc.close();
                        float inte = 0.0066f;
                        cal = (prin * inte * Math.pow(1 + inte, ti)) / (Math.pow(1 + inte, ti) - 1);
                        System.out.println("The Interest is:" + cal);
                        System.out.println("In Time Period:" + ti);
                        break;
                }
                break;


            case 3:
                System.out.println("You have chosen CCC Bank");
                System.out.println("Now choose the loan type \n");
                System.out.println("1. Educational Loan \n 2.House Loan");
                int ccc = in.nextInt();
                switch (ccc) {
                    case 1:
                        double p, t, calc;
                        System.out.println("Enter the amount:");
                        Scanner scan = new Scanner(System.in);
                        p = scan.nextFloat();
                        System.out.println("Enter the Time Period:");
                        t = scan.nextFloat();
                        scan.close();
                        float interest = 0.005f;
                        calc = (p * interest * Math.pow(1 + interest, t)) / (Math.pow(1 + interest, t) - 1);
                        System.out.println("The Interest is:" + calc);
                        System.out.println("In Time Period:" + t);
                        break;

                    case 2:
                        double prin, ti, cal;
                        System.out.println("Enter the amount:");
                        Scanner s = new Scanner(System.in);
                        prin = s.nextFloat();
                        System.out.println("Enter the Time Period:");
                        ti = s.nextFloat();
                        s.close();
                        float inte = 0.005f;
                        cal = (prin * inte * Math.pow(1 + inte, ti)) / (Math.pow(1 + inte, ti) - 1);
                        System.out.println("The Interest is:" + cal);
                        System.out.println("In Time Period:" + ti);
                        break;
                }
                break;


            case 4:
                System.out.println("You have chosen DDD Bank");
                System.out.println("Now choose the loan type \n");
                System.out.println("1. Educational Loan \n 2.House Loan");
                int ddd = in.nextInt();
                switch (ddd) {
                    case 1:
                        double p, t, calc;
                        System.out.println("Enter the amount:");
                        Scanner scan = new Scanner(System.in);
                        p = scan.nextFloat();
                        System.out.println("Enter the Time Period:");
                        t = scan.nextFloat();
                        scan.close();
                        float interest = 0.0066f;
                        calc = (p * interest * Math.pow(1 + interest, t)) / (Math.pow(1 + interest, t) - 1);
                        System.out.println("The Interest is:" + calc);
                        System.out.println("In Time Period:" + t);
                        break;

                    case 2:
                        double prin, ti, cal;
                        System.out.println("Enter the amount:");
                        Scanner a = new Scanner(System.in);
                        prin = a.nextFloat();
                        System.out.println("Enter the Time Period:");
                        ti = a.nextFloat();
                        a.close();
                        float inte = 0.0014f;
                        cal = (prin * inte * Math.pow(1 + inte, ti)) / (Math.pow(1 + inte, ti) - 1);
                        System.out.println("The Interest is:" + cal);
                        System.out.println("In Time Period:" + ti);
                        break;
                }
                break;
            default:
                System.out.println("Invalid choice");
        }
    }
}



